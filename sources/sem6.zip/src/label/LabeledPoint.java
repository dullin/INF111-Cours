package label;

import java.awt.*;

public class LabeledPoint extends Point {
    private String label;

    public LabeledPoint(int x, int y, String label) {
        super(x, y);
        this.label = label;
    }

    @Override
    public String toString() {
        return super.toString() + "LabeledPoint{" +
                "label='" + label + '\'' +
                '}';
    }

    public static void main(String[] args) {
        LabeledPoint p = new LabeledPoint(4, 5, "Init");

        System.out.println(p);
    }
}
