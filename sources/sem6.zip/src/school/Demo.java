package school;

public class Demo {
    public static void main(String[] args) {
        Person[] list = new Person[3];

        list[0] = new Person("Bob", 1945);
        list[1] = new Student("Lyonne", 2003, "CompSci");
        list[2] = new Instructor("Gary", 1985, 35325);

        for (Person e :list) {
            System.out.println(e);
        }
    }
}
