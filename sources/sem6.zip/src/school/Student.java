package school;

public class Student extends Person {
    String major;

    public Student(String name, int yearOfBirth, String major) {
        super(name, yearOfBirth);
        this.major = major;
    }

    @Override
    public String toString() {
        return super.toString() + "Student{" +
                "major='" + major + '\'' +
                '}';
    }
}
