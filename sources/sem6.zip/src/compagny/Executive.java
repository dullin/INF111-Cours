package compagny;

public class Executive extends Manager {
    double bonus;

    public Executive(String name, double salary, String department, double bonus) {
        super(name, salary, department);
        this.bonus = bonus;
    }

    @Override
    public String toString() {
        return super.toString() + "Executive{" +
                "bonus=" + bonus +
                '}';
    }
}
