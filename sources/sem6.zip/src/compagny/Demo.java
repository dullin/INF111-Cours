package compagny;

public class Demo {
    public static void main(String[] args) {
        Executive ex = new Executive("Bob", 35339, "Logistics", 4534);

        System.out.println(ex);
    }
}
