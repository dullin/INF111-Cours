package supermarket;

import java.util.ArrayList;

public class Store {

    ArrayList<Customer> list = new ArrayList<Customer>();

    public void addSale(String customerName, double amount){
        list.add(new Customer(customerName, amount));
    }

    public String nameOfBestCustomer(){
        ArrayList<String> names = new ArrayList<String>();

        double amountMax = 0;
        String nameMax = "";
        for (Customer e : list) {
            if (e.amount > amountMax){
                amountMax = e.amount;
                nameMax = e.name;
            }
        }

        return nameMax;
    }

    public static void main(String[] args) {
        Store store = new Store();

        store.addSale("Bob", 43);
        store.addSale("Jane", 67);
        store.addSale("Guy", 12);
        store.addSale("Lyonne", 120);
        store.addSale("Bouba", 4);

        System.out.println(store.nameOfBestCustomer());
    }
}
